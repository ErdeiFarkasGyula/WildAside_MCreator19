
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.gyula.wildaside.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.common.Mod;

import net.minecraft.world.level.levelgen.feature.Feature;

import net.gyula.wildaside.world.features.plants.YellowGlowingHickorySaplingFeature;
import net.gyula.wildaside.world.features.plants.VibrionSporeholderFeature;
import net.gyula.wildaside.world.features.plants.VibrionRootsFeature;
import net.gyula.wildaside.world.features.plants.SubstiliumSproutsFeature;
import net.gyula.wildaside.world.features.plants.RedGlowingHickorySaplingFeature;
import net.gyula.wildaside.world.features.plants.HickorySaplingFeature;
import net.gyula.wildaside.world.features.plants.GreenGlowingHickorySaplingFeature;
import net.gyula.wildaside.world.features.plants.BrownGlowingHickorySaplingFeature;
import net.gyula.wildaside.world.features.ores.OvergrownEntoriumOreFeature;
import net.gyula.wildaside.world.features.ores.CompressedSubstiliumSoilFeature;
import net.gyula.wildaside.WildasideMod;

@Mod.EventBusSubscriber
public class WildasideModFeatures {
	public static final DeferredRegister<Feature<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.FEATURES, WildasideMod.MODID);
	public static final RegistryObject<Feature<?>> VIBRION_SPOREHOLDER = REGISTRY.register("vibrion_sporeholder", VibrionSporeholderFeature::feature);
	public static final RegistryObject<Feature<?>> VIBRION_ROOTS = REGISTRY.register("vibrion_roots", VibrionRootsFeature::feature);
	public static final RegistryObject<Feature<?>> SUBSTILIUM_SPROUTS = REGISTRY.register("substilium_sprouts", SubstiliumSproutsFeature::feature);
	public static final RegistryObject<Feature<?>> OVERGROWN_ENTORIUM_ORE = REGISTRY.register("overgrown_entorium_ore", OvergrownEntoriumOreFeature::feature);
	public static final RegistryObject<Feature<?>> HICKORY_SAPLING = REGISTRY.register("hickory_sapling", HickorySaplingFeature::feature);
	public static final RegistryObject<Feature<?>> RED_GLOWING_HICKORY_SAPLING = REGISTRY.register("red_glowing_hickory_sapling", RedGlowingHickorySaplingFeature::feature);
	public static final RegistryObject<Feature<?>> YELLOW_GLOWING_HICKORY_SAPLING = REGISTRY.register("yellow_glowing_hickory_sapling", YellowGlowingHickorySaplingFeature::feature);
	public static final RegistryObject<Feature<?>> BROWN_GLOWING_HICKORY_SAPLING = REGISTRY.register("brown_glowing_hickory_sapling", BrownGlowingHickorySaplingFeature::feature);
	public static final RegistryObject<Feature<?>> GREEN_GLOWING_HICKORY_SAPLING = REGISTRY.register("green_glowing_hickory_sapling", GreenGlowingHickorySaplingFeature::feature);
	public static final RegistryObject<Feature<?>> COMPRESSED_SUBSTILIUM_SOIL = REGISTRY.register("compressed_substilium_soil", CompressedSubstiliumSoilFeature::feature);
}
